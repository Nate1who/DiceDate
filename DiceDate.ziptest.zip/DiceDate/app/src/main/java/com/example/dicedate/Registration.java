package com.example.dicedate;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Patterns;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.navigation.Navigation;
public class Registration extends Fragment {
    private EditText editTextInputLogin, editTextInputPassword;
    private Button buttonRegistration, buttonGoToEnter;
    private SharedPreferences sharedPreferences;

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_registration, container, false);

        editTextInputLogin = view.findViewById(R.id.editTextInput_login);
        editTextInputPassword = view.findViewById(R.id.editTextInput_password);
        buttonRegistration = view.findViewById(R.id.button_registration);
        buttonGoToEnter = view.findViewById(R.id.button_registration_go_to_enter);

        sharedPreferences = requireActivity().getSharedPreferences("user_prefs", 0);

        return view;
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        buttonRegistration.setOnClickListener(v -> {
            String email = editTextInputLogin.getText().toString().trim();
            String password = editTextInputPassword.getText().toString().trim();

            if(validateInput(email, password)) {
                try {
                    SharedPreferences.Editor editor = sharedPreferences.edit();
                    editor.putString("email", email);
                    editor.putString("password", Integer.toString(password.hashCode()));
                    editor.apply();

                    Navigation.findNavController(view).navigate(R.id.NavigationToMain_Registration);
                } catch (Exception e) {
                    Toast.makeText(requireContext(), "Ошибка сохранения", Toast.LENGTH_SHORT).show();
                }
            }
        });

        buttonGoToEnter.setOnClickListener(v -> {
            Navigation.findNavController(view).navigate(R.id.NavigationToEnter);
        });
    }

    private boolean validateInput(String email, String password) {
        if (email.isEmpty() || !Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            editTextInputLogin.setError("Введите корректный email");
            return false;
        }
        if (password.isEmpty() || password.length() < 6) {
            editTextInputPassword.setError("Пароль должен быть не менее 6 символов");
            return false;
        }
        return true;
    }
}