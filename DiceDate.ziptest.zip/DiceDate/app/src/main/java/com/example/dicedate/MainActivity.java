package com.example.dicedate;

import android.content.SharedPreferences;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.NavigationUI;

import com.example.dicedate.R;

public class MainActivity extends AppCompatActivity {
    private SharedPreferences sharedPreferences;
    private static final String SHARED_PREF_NAME = "user_prefs";
    private static final String KEY_EMAIL = "email";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        sharedPreferences = getSharedPreferences(SHARED_PREF_NAME, MODE_PRIVATE);

        // Ждём инициализации вью
        findViewById(android.R.id.content).postDelayed(this::initializeNavigation, 100);
    }

    private void initializeNavigation() {
        try {
            NavController navController = Navigation.findNavController(this, R.id.fragmentContainerView);

            // Проверяем авторизацию
            if (sharedPreferences.contains(KEY_EMAIL)) {
                navController.navigate(R.id.main2);
            }
            // Если не авторизован - остаётся на стартовом экране (определено в nav_graph)
        } catch (Exception e) {
            e.printStackTrace();
            // Если что-то пошло не так - пересоздаём активность
            recreate();
        }
    }
}